/**********************
ar_stats.c
Author: Suren Byna <SByna@lbl.gov>
Lawrence Berkeley Lab

Description:
This program goes through the output of ar_detect and 
gives the statistics of atmospheric rivers.

**********************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <math.h>

#include "ar_stats.cpp"

// The main function
int main (int argc, char **argv)
{
	char *ardet_output_file;
	char *stats_output_file;

	if (argc == 3)
	{
		ardet_output_file = argv[1];
		stats_output_file = argv[2];
	}
	else
	{
		printf ("Usage: ar_stats ardet_output stats_output \n");
	}

	count_events_in_file (ardet_output_file, stats_output_file);
	
	
#ifdef DEBUG
	printf ("Input: %s  Ouput: %s \n", ardet_output_file, stats_output_file);
#endif

	return 1;
}
