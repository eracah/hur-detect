#include <iostream>
#include <Python/Python.h>

using namespace std;

int main(int u, int o) {
    cout << "Hello, World!" << endl;
    return 0;
}

string calc() {
    main(u, o);

    return "";
}



