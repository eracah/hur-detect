
import logging
import numpy as np
import h5py
import os
# import neon
#
from neon.datasets.dataset import Dataset
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
#

f = h5py.File("/Users/DOE6903584/NERSC/mantissa/joaquin/atmosphericriver_MC.h5", 'r')

AR = f['AR']
nAR = f['Non_AR']

# v = self.variable            # which variable to pick
tr = 500    # how many training rows * 2
te = 500

AR_data = np.vstack(AR.value)
nAR_data = np.vstack(nAR.value)

shape_AR = AR_data.shape
shape_nAR = nAR_data.shape

labels = np.array(['AR', 'nAR'],dtype='|S3')

# 35392 comes fropm shape np.zeros([158,224]).flatten()

AR_train = AR_data[:tr]
nAR_train = nAR_data[:tr]

AR_test = AR_data[tr:tr+te]
nAR_test = nAR_data[tr:tr+te]

AR_flat_train = np.zeros([AR_train.shape[0], 35392])
nAR_flat_train = np.zeros([nAR_train.shape[0], 35392])
AR_flat_test = np.zeros([AR_test.shape[0], 35392])
nAR_flat_test = np.zeros([nAR_test.shape[0], 35392])

for ij in range(0,AR_train.shape[0]):
    AR_flat_train[ij] = AR_train[ij].flatten()
    nAR_flat_train[ij] = nAR_train[ij].flatten()
    print(ij)

for ij in range(0,AR_test.shape[0]):
    AR_flat_test[ij] = AR_test[ij].flatten()
    nAR_flat_test[ij] = nAR_test[ij].flatten()

data_train = np.concatenate([AR_flat_train, nAR_flat_train])
data_test = np.concatenate([AR_flat_test, nAR_flat_test])
# labels_train = np.concatenate([lAR_flat_train, lnAR_flat_train])
# labels_test = np.concatenate([lAR_flat_test, lnAR_flat_test])
labels_train=np.vstack(([[1,0]] * (AR_train.shape[0]),[[0,1]] * (AR_train.shape[0])))
labels_test=np.vstack(([[1,0]] * (AR_test.shape[0]),[[0,1]] * (AR_test.shape[0])))