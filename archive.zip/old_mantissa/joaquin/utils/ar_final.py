# #
# #
import logging
import numpy as np
import h5py
import os
# import neon
#

from scipy import stats
from neon.datasets.dataset import Dataset

# logging.basicConfig(level=logging.DEBUG)
# logger = logging.getLogger(__name__)

import pickle

landmask_file = "/Users/DOE6903584/NERSC/mantissa/joaquin/landmask_imgs.pkl"
hdf5_file = "/Users/DOE6903584/NERSC/mantissa/joaquin/atmosphericriver_cleannegative.h5"

landmask_data = np.array(pickle.load(open(landmask_file))['mask'])
f = h5py.File(hdf5_file, 'r')

AR = f['AR']
nAR = f['Non_AR']

    # training_sizeAR: 2000,
    # training_sizenAR: 1000,
    # test_sizeAR: 284,
    # test_sizenAR: 330,

tr_AR = 2000
te_AR = 284
tr_nAR = 1000
te_nAR = 330

AR_data = np.vstack(AR.value)
nAR_data = np.vstack(nAR.value)

AR_train = AR_data[:tr_AR]
nAR_train = nAR_data[:tr_nAR]

AR_test = AR_data[tr_AR:tr_AR+te_AR]
nAR_test = nAR_data[tr_nAR:tr_nAR+te_nAR]

AR_flat_train = np.zeros([AR_train.shape[0], 35392])
labels_train_AR = np.zeros([AR_train.shape[0], 2])
for ij in range(0,AR_train.shape[0]):
    AR_flat_train[ij] = AR_train[ij].flatten()
    labels_train_AR[ij][0] = 1

nAR_flat_train = np.zeros([nAR_train.shape[0], 35392])
labels_train_nAR = np.zeros([nAR_train.shape[0], 2])
for ij in range(0,nAR_train.shape[0]):
    nAR_flat_train[ij] = AR_train[ij].flatten()
    labels_train_nAR[ij][1] = 1

AR_flat_test = np.zeros([AR_test.shape[0], 35392])
labels_test_AR = np.zeros([AR_test.shape[0], 2])
for ij in range(0,AR_test.shape[0]):
    AR_flat_test[ij] = AR_test[ij].flatten()
    labels_test_AR[ij][0] = 1

nAR_flat_test = np.zeros([nAR_test.shape[0], 35392])
labels_test_nAR = np.zeros([nAR_test.shape[0], 2])
for ij in range(0,nAR_test.shape[0]):
    nAR_flat_test[ij] = nAR_test[ij].flatten()
    labels_test_nAR[ij][1] = 1


sAR = range(len(AR_flat_train))
snAR = range(len(nAR_flat_train))

np.random.shuffle(sAR)
np.random.shuffle(snAR)

AR_flat_train = AR_flat_train[sAR]
nAR_flat_train = nAR_flat_train[snAR]

labels_train = np.hstack(([labels_train_AR],[labels_train_nAR]))[0]
labels_test = np.hstack(([labels_test_AR],[labels_test_nAR]))[0]

data_train = np.hstack(([AR_flat_train], [nAR_flat_train]))[0]
data_test = np.hstack(([AR_flat_test], [nAR_flat_test]))[0]