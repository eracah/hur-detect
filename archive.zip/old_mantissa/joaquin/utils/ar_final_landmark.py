# #
# #
import logging
import numpy as np
import h5py
import os
# import neon
#

from scipy import stats
from neon.datasets.dataset import Dataset

# logging.basicConfig(level=logging.DEBUG)
# logger = logging.getLogger(__name__)

import pickle

# landmask_file = "/Users/DOE6903584/NERSC/mantissa/joaquin/landmask_imgs.pkl"
hdf5_file = "/Users/DOE6903584/NERSC/mantissa/joaquin/atmosphericriver_cleannegative_intersect.h5"

# landmask_data = np.array(pickle.load(open(landmask_file))['mask'])
f = h5py.File(hdf5_file, 'r')

AR = f['AR']
nAR = f['Non_AR']

    # training_sizeAR: 2000,
    # training_sizenAR: 1000,
    # test_sizeAR: 284,
    # test_sizenAR: 330,

tr_AR = 2000
te_AR = 284
tr_nAR = 1000
te_nAR = 330

AR_data = np.array(AR.value)
nAR_data = np.array(nAR.value)
#
# landmask = []
# for ij in range(0,AR_data.shape[0]):
#     landmask[ij] = AR_data[ij][1].flatten()


AR_train = AR_data[:tr_AR]
nAR_train = nAR_data[:tr_nAR]

AR_test = AR_data[tr_AR:tr_AR+te_AR]
nAR_test = nAR_data[tr_nAR:tr_nAR+te_nAR]

AR_flat_train = np.zeros([AR_train.shape[0], 35392])
AR_flat_train2 = np.zeros([AR_train.shape[0], 35392*2])
AR_flat_LM_tr = np.zeros([AR_train.shape[0], 35392])
labels_train_AR = np.zeros([AR_train.shape[0], 2])
for ij in range(0,AR_train.shape[0]):
    AR_flat_train[ij] = AR_train[ij][0].flatten()
    AR_flat_LM_tr[ij] = AR_train[ij][1].flatten()
    AR_flat_train2[ij] = np.hstack(([AR_flat_train[ij]],[AR_flat_LM_tr[ij]]))
    labels_train_AR[ij][0] = 1

nAR_flat_train = np.zeros([nAR_train.shape[0], 35392])
nAR_flat_train2 = np.zeros([nAR_train.shape[0], 35392*2])
nAR_flat_LM_tr = np.zeros([nAR_train.shape[0], 35392])
labels_train_nAR = np.zeros([nAR_train.shape[0], 2])
for ij in range(0,nAR_train.shape[0]):
    nAR_flat_train[ij] = nAR_train[ij][0].flatten()
    nAR_flat_LM_tr[ij] = nAR_train[ij][1].flatten()
    nAR_flat_train2[ij] = np.hstack(([nAR_flat_train[ij]],[nAR_flat_LM_tr[ij]])) #TODO
    labels_train_nAR[ij][1] = 1

AR_flat_test = np.zeros([AR_test.shape[0], 35392])
AR_flat_test2 = np.zeros([AR_test.shape[0], 35392*2])
AR_flat_LM_te = np.zeros([AR_test.shape[0], 35392])
labels_test_AR = np.zeros([AR_test.shape[0], 2])
for ij in range(0,AR_test.shape[0]):
    AR_flat_test[ij] = AR_test[ij][0].flatten()
    AR_flat_LM_te[ij] = AR_test[ij][1].flatten()
    AR_flat_test2[ij] = np.hstack(([AR_flat_test[ij]],[AR_flat_LM_te[ij]])) #TODO
    labels_test_AR[ij][0] = 1

nAR_flat_test = np.zeros([nAR_test.shape[0], 35392])
nAR_flat_test2 = np.zeros([nAR_test.shape[0], 35392*2])
nAR_flat_LM_te = np.zeros([nAR_test.shape[0], 35392])
labels_test_nAR = np.zeros([nAR_test.shape[0], 2])
for ij in range(0,nAR_test.shape[0]):
    nAR_flat_test[ij] = nAR_test[ij][0].flatten()
    nAR_flat_LM_te[ij] = nAR_test[ij][1].flatten()
    nAR_flat_test2[ij] = np.hstack(([nAR_flat_test[ij]],[nAR_flat_LM_te[ij]])) #TODO
    labels_test_nAR[ij][1] = 1


labels_train = np.hstack(([labels_train_AR],[labels_train_nAR]))[0]
labels_test = np.hstack(([labels_test_AR],[labels_test_nAR]))[0]

data_train = np.hstack(([AR_flat_train2], [nAR_flat_train2]))[0]
data_test = np.hstack(([AR_flat_test2], [nAR_flat_test2]))[0]

# sAR = range(len(AR_flat_train))
# snAR = range(len(nAR_flat_train))
#
# np.random.shuffle(sAR)
# np.random.shuffle(snAR)
#
# AR_flat_train = AR_flat_train[sAR]
# nAR_flat_train = nAR_flat_train[snAR]
#
# labels_train = np.hstack(([labels_train_AR],[labels_train_nAR]))[0]
# labels_test = np.hstack(([labels_test_AR],[labels_test_nAR]))[0]
#
# train_stack_AR=np.hstack(([AR_flat_train],[AR_flat_LM_tr]))
# train_stack_nAR=np.hstack(([nAR_flat_train],[nAR_flat_LM_tr]))
#
# test_stack_AR=np.hstack(([AR_flat_test],[AR_flat_LM_te]))
# test_stack_nAR=np.hstack(([nAR_flat_test],[nAR_flat_LM_te]))
#
# data_train = np.hstack(([train_stack_AR], [train_stack_nAR]))[0]
# data_test = np.hstack(([test_stack_AR], [test_stack_nAR]))[0]