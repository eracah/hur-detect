"""
Neon utils for playing around with hurricane data
"""
import logging
import matplotlib.pyplot as plt
import numpy as np
import ipdb

from neon.models.mlp import MLP
from neon.experiments.fit_predict_err import FitPredictErrorExperiment

logger = logging.getLogger(__name__)

class DebugExperiment(FitPredictErrorExperiment):

    def run(self):
        # [DEBUG] no changes to superclass here

        super(FitPredictErrorExperiment, self).run()
        
        predictions = self.model.predict(self.datasets)
        self.model.error_metrics(self.datasets, predictions)


class DebugMLP(MLP):

    def error_metrics(self, datasets, predictions, train=True, test=True,
                      validation=True):
        # simple misclassification error
        items = []
        if train:
            items.append('train')
        if test:
            items.append('test')
        if validation:
            items.append('validation')
        for idx in xrange(len(datasets)):
            ds = datasets[idx]
            preds = predictions[idx]
            targets = ds.get_targets(train=True, test=True, validation=True)
            for item in items:
                if item in targets and item in preds:
                    misclass = ds.backend.empty(preds[item].shape)
                    ds.backend.not_equal(preds[item], ds.backend.argmax(
                        targets[item], axis=targets[item].minor_axis()),
                        misclass)
                    if item == 'test' and self.plots:
                        mis = misclass.asnumpyarray()
                        plt.figure(1)
                        plt.clf()
                        plt.plot(np.cumsum(misclass.asnumpyarray()))

                        te = 500
                        a = np.where(mis[:te] == 1)
                        b = np.where(mis[te:] == 1)

                        a = ds.get_inputs(test=True)['test'][a].asnumpyarray().reshape((-1,33,33))
                        b = ds.get_inputs(test=True)['test'][b].asnumpyarray().reshape((-1,33,33))

                        def plot(img, fig):
                            plt.figure(fig, figsize=(5,10))
                            cols = len(img)
                            c = 1
                            for i in img:
                                plt.subplot(1,cols,c)
                                plt.imshow(i)
                                plt.xticks([])
                                plt.yticks([])
                                c += 1
                            plt.subplots_adjust(left=0.05, right=0.95, bottom=0.05,
                                                top=0.95, wspace=0.01)
                            ipdb.set_trace()
                                

                        ipdb.set_trace()
                        plot(a[:10], fig=2)
                        plot(b[:10], fig=3)

                        ipdb.set_trace()
                        
                        
                    self.result = ds.backend.mean(misclass)
                    logging.info("%s set misclass rate: %0.5f%%" % (
                        item, 100 * self.result))
        # TODO: return values instead?
    


