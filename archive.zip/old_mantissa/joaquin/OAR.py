__author__ = 'jcorrea'

# import pandas as pd
import os
#
path = "/Users/DOE6903584/Documents/OAR"
# filename = "ref_pubs_14"
filename1 = "ref_pubs_14.1"
#
# file = os.path.join(path, filename)
file1 = os.path.join(path, filename1)
#
# data_names = ["firstname", "lastname", "office_label", "sci_cat_label", "refereed_pubs"]
#
# data_dtype = {"firstname": str,
#               "lastname": str,
#               "office_label": str,
#               "sci_cat_label": str,
#               "refereed_pubs": str}
#
# data = pd.read_csv(file, sep="|", names=data_names, dtype=data_dtype)
# data1 = pd.read_csv(file1, sep="\&#013", names=["data"], dtype={"data": str}, skip_blank_lines=False)

#M
#N
#O
#P
#Q
#R
#S
#T
#U
#V
#W
#X
#Y
#Z

import re

#DuckYoung|Kim|BES|Materials Science|
f = open(file1, 'r')

# line = "Cats are smarter than dogs"
# line = "#DuckYoung|Kim|BES|Materials Science|"

# r'(.*) are (.*?) .*'
# r'#*|*|*|*|'

# matchObj = re.match( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)
# if matchObj:
#    print "match --> matchObj.group() : ", matchObj.group()
# else:
#    print "No match!!"

# searchObj = re.search( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)
# if searchObj:
#    print "search --> searchObj.group() : ", searchObj.group()
# else:
#    print "Nothing found!!"
#
uu = os.path.join(path, "test")
u = open(uu, 'w')
#
# match = False
# while not searchObj:
#     line = f.readline()
#     searchObj = re.search( r'#(.*)|(.*)|(.*)|(.*)|', line, re.M|re.I)

def file_len(full_path):
  """ Count number of lines in a file."""
  f = open(full_path)
  nr_of_lines = sum(1 for line in f)
  f.close()
  return nr_of_lines

combos = [r'^#M(.*)|(.*)|(.*)|(.*)|$',
          r'^#N(.*)|(.*)|(.*)|(.*)|$',
          r'^#O(.*)|(.*)|(.*)|(.*)|$',
          r'^#P(.*)|(.*)|(.*)|(.*)|$',
          r'^#Q(.*)|(.*)|(.*)|(.*)|$',
          r'^#R(.*)|(.*)|(.*)|(.*)|$',
          r'^#S(.*)|(.*)|(.*)|(.*)|$',
          r'^#T(.*)|(.*)|(.*)|(.*)|$',
          r'^#U(.*)|(.*)|(.*)|(.*)|$',
          r'^#V(.*)|(.*)|(.*)|(.*)|$',
          r'^#X(.*)|(.*)|(.*)|(.*)|$',
          r'^#Y(.*)|(.*)|(.*)|(.*)|$',
          r'^#Z(.*)|(.*)|(.*)|(.*)|$']

c = 0

for ii in range(0, file_len(file1)):
    # line = f.readline()
    for idx, com in enumerate(combos):
        line = f.readline()
        searchObj = re.search(com, line, re.M|re.I)
        if searchObj.group(1) is not None:
            # print(searchObj.group())
            # S = True
            while line != re.search(combos[idx+1], line, re.M|re.I).group(1):
                # if comp == searchObj.group(1):
                # hola = "%s \n" % (searchObj.group())
                hola = "%s \n" % (line)
                u.write(hola)
                line = f.readline()
                # else:
                #     S = False

                # c = c + 1
                # print(hola)

u.close()


# print("hello")
# f.close()
# if not a:
#   print "List is empty"
#
# while temperature > 112: # first while loop code
#     print(temperature)
#     temperature = temperature - 1
#
# print('The tea is cool enough.')