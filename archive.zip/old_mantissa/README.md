MANTISSA TOOLS
===

Folder structure
---
  - Personal folders: Place to develope your own code
    - prabhat
    - sang
    - yunjie
    - joaquin
  - Commons: Common code is stored here, including the libraries and packages we all agree to work with
    - commons
      - neon
      - sang_ml
      - others?
  - Utils: Scripts and small tools 
    - utils

Data
---
Data is stored:
  - `/project/projectdirs/mantissa/climate/Yunjie/ar_patch`