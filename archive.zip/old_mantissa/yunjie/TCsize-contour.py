#not sure why the code is slowing down ???/
"""
To calculate the TC/ETC size based on the detection results from TECA
there are multiple method of calculating the extent of tropical cyclones:
1) radius of vanishing wind
2) radius of radius of outmost isobar
3) vorticity decrease to a certain level
...
here we are going to calcualte the TC/ ETC size based on the outermost isobar
also note that the actual lat/lon coordinate system, and lat/lon indexs are both used in the script, pay attention
some of the functions are taken from sang_hurricane.py where he extract hurricane patches
"""

import os
import numpy
import netCDF4 as cdf
import pandas
import matplotlib
from matplotlib import pyplot
import ipdb
import math

"""
define common arrays of time, lat lon index
"""
delta=111.325   #one degree to kilo meters

"""
number of grid box
I: time index
J: lat index
K: lon index
"""

IJK=(8,768,1152)
I,J,K =IJK

dJ=180.0/(J-1)
dK=360.0/K

gI=numpy.arange(0,23,1)
gJ=numpy.arange(-90.0,90+dJ,dJ)
gK=numpy.arange(0,360.0,dK)


"""
define some common used functions 
"""
def nearest_index(x,v):
    """
    find nearest index of x in array v, and return the index
    """
    r=numpy.searchsorted(v,x,"right")-1
    return r if numpy.linalg.norm(v[r]-x) <= numpy.linalg.norm(v[r+1]-x) else r+1


def teca_process(fname, hr, lt, ln):
    dat=numpy.genfromtxt(fname,delimiter=",",skip_header=0,usecols=(0,1,2,3,4,5,6,7,8,9,10,11,12,13),names=True,\
                         dtype=("i","i","i","i","f","f","f","f","f","f","f","i","f","f"))
    #precip rate unit in CAM is m/s, in TECA is mm/day
    dat=pandas.DataFrame(dat)  # convert to data frame, easy to handle
    dat["time_in"]=nearest_index(x=dat['hour'],v=hr)
    dat["lat_in"]=nearest_index(x=dat['lat'],v=lt)
    dat["lon_in"]=nearest_index(x=dat['lon'],v=ln)
    # not sure what happend, but the file names are different
    if year <=1984:
       dat["camfile"]=["cam5_1_amip_run2.cam2.h2.%4d-%02d-%02d-00000.nc" \
            %(one['year'],one['month'],one['day']) for i, one in dat.iterrows() ]
    else:
       dat["camfile"]=["cam5_1_amip_run2.cam2.h2.%4d-%02d-%02d-10800.nc" \
            %(one['year'],one['month'],one['day']) for i, one in dat.iterrows() ]
    
    return dat

def cdf_process(fname,center):
    cam_data=cdf.Dataset(fname,"r")
    LAT=cam_data.variables["lat"]
    LON=cam_data.variables["lon"]
    
    TMQ=cam_data.variables["TMQ"]
    TMQ=TMQ[(center[-1]/3),:,:]

    PSL=cam_data.variables["PSL"]
    PSL=PSL[(center[-1]/3),:,:] # uses index to extract data rather than coordinate value 
    PSL=PSL/100.0  # convert to hPa
     
    PRECT=cam_data.variables["PRECT"]
    PRECT=PRECT[(center[-1]/3),:,:]

    return (LAT, LON, PSL, PRECT, TMQ)    

def separate_basin(center):  # not used for now 
    """
    separate TCs bsed on basin. There are 7 major basins around the world: north atlantic, northeast pacific, northwest pacific,north
    indian ocean, south east indian ocean, south west indian ocean, southwest pacific.
    north atlantic: 0-90N,       ; northeast pacific: 0-90N
    """

def haversine(lon1, lat1, lon2, lat2):  
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees).
    Source: http://gis.stackexchange.com/a/56589/15183
    """
    # convert decimal degrees to radians 
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])
    # haversine formula 
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a)) 
    km = 6367 * c
    return km

def radius_cal(center,center_coord,la, lo,center_low, press):
    """
    radius calculation will be to find the outer most closed sea level pressure isobar, 
    the average TC size would be around 400 Km, thus uses a larger box to bound TECA detected
    TC, and contour the SLP, and find the outer most closed isobar. 
    If the detected TC center is close to 0 or 360, wrap over
    
    alternative way is do not bound TC/ETC but calculate the contour for the entire field, then find  
    the center minima detected by TECA, and go from there.
    """
    #ipdb.set_trace()
    bound_size= 1000.0 # the bound size for TC

    num_cell_lat=int(bound_size/(dJ*delta)) # corresponding number of cells on lat
    num_cell_lon=int(bound_size/(dK*delta))
    bound_cell_lat_index=numpy.arange(center[0]-num_cell_lat,center[0]+num_cell_lat)  # cell index
    bound_cell_lon_index=numpy.arange(center[1]-num_cell_lon,center[1]+num_cell_lon)
 
    box=numpy.take(press,bound_cell_lat_index, axis=0, mode="wrap")
    box=numpy.take(box,bound_cell_lon_index,axis=1,mode="wrap")
    
    lat_coord=numpy.take(la,bound_cell_lat_index,axis=0,mode="wrap") #wrap over across boundary
    lon_coord=numpy.take(lo,bound_cell_lon_index,axis=0,mode="wrap")
    
    lev=numpy.arange(950,1030,1)  #pressure contour level, every 20 Pa
    cn=pyplot.contour(lon_coord, lat_coord,box,levels=lev)
    #cn is a collection of lines, and should be equal length as lev

    """
    now we are going to get the vertices of each contour line, and check whether they are closed or not
    """
    k=0    #pressure level
    seg=0  # which segment of contour (e.g. contour can be piece wise)
    n=0     #index of contour line
    epsilon =0.1  
    for le, collection in zip(cn.levels,cn.collections):
        level=le    # which level is the contour
        path=collection.get_paths()
        if len(path) != 0: 
           for i in numpy.arange(len(path)):  
               vertic=path[i].vertices #vertic is an array containing x and y cordinates

               """
               calculate the length of the contour lines
               """
               lenofpath=0
               for j in numpy.arange(vertic.shape[0]-1):
                   lenofpath=lenofpath+ haversine(vertic[j,0], vertic[j,1],vertic[j+1,0],vertic[j+1,1])
               #print lenofpath
               #print level
               #print vertic
               #print center_coord
               #print numpy.min(vertic[:,1]),numpy.max(vertic[:,1]),numpy.min(vertic[:,0]),numpy.max(vertic[:,0])
               """
               evaluate 1) whether the contour is closed 2) whether the closed contour contain hurricane center. 
               If closed, the start and end point should equal 
               another criteria Wernli et al. 2006 use is the length of the contour, in their code, the length of 
               outmost isobar should be less than 7500 Km. Here we first bound the hurricane with a bounding box
               thus do not need to check the lenght of outermost isobar. 
               (Bound radius for TC and ETC will be different, because their spatial scale is different)    
               """
               if  abs(vertic[0,0]-vertic[-1,0]) <= epsilon   and abs(vertic[0,1]-vertic[-1,1]) <= epsilon \
                   and  path[i].contains_point((center_coord[1],center_coord[0])) and lenofpath<=4000:
                   # Wernli 2006 paper, uses a criteria of lenght of contour to check the ETC (7500), 
                   k=level
                   seg=i
                   #print level
                   #print vertic

    outmostlevel=k
    try:
       n=numpy.ndarray.tolist(cn.levels).index(k)
       outmostbar=cn.collections[n].get_paths()[seg].vertices

       print("outter most pressure level ...%f" %k)
    
       # now find the polygon that bound TC/ETC, axis=0 is longitute, axis=1 is latitude 
       polygon_lat=outmostbar[:,1]
       polygon_lon=outmostbar[:,0]

       """
       now that we find the outer most sea level pressure isobar, we are going to find the corresponding cells with 
       in the contour and mark them as the area that we are interested in
       """
       # find the grid cells within the contour and mask them
       all_grid=[]
       for i in lat_coord:
           for j in lon_coord:
               all_grid.append((j,i))
       #ipdb.set_trace()
       mask=cn.collections[n].get_paths()[seg].contains_points(all_grid)
       marker=numpy.array(all_grid)[numpy.array(mask)]
    
       #add points along the contour line to marker
       marker=numpy.append(marker,outmostbar,axis=0)
    
       # find the corresponding cell index       
       marker_index=numpy.zeros(marker.shape)
       marker_index[:,0]=nearest_index(x=marker[:,0],v=gK)
       marker_index[:,1]=nearest_index(x=marker[:,1],v=gJ)
    
       # remove duplicated cells
       marker_index=sorted(marker_index.tolist())
       marker_index=[marker_index[i] for i in range(len(marker_index)) if i==0 or marker_index[i]!= marker_index[i-1]]
    
       return (polygon_lat, polygon_lon, marker[:,1], marker[:,0], marker_index)    
    
    except:
       """
       it can happen that no level of contour satisfy all criteria above, 1) some of detection results from TECA seems wired 
       (e.g. center did not line well with pressure center from pressure map      
       2) at the end of storm, core pressure level may have returned to environmental level
       """
       print ("did not find contour associated with k %f" %k) 
       return ((),(),(),(),())

def precip_cal(cells, center_coord,la, lo, pre, iwv):
   
    total_precip=0
    total_area=0
    total_tmq=0
    mm=0
    unit_area=dJ*delta*dK*delta 
    #ipdb.set_trace()
    for one in cells:
        pr=pre[one[1],one[0]]*86400000 
        total_precip=total_precip+pr    # convert m/s to mm/day 
        total_area=total_area+unit_area    # in square km 
        total_tmq=total_tmq+iwv[one[1],one[0]]

        """
        calculate the distance of max precipitation from cente. Note TECA has the max precip radius 
        """
       
       # if pr >mm: 
       #    mm=pr
       #    maxp_lat=la[one[1]]
       #    maxp_lon=lo[one[0]]
   # dis=haversine(maxp_lon,maxp_lat,center_coord[1],center_coord[0])
   # print maxp_lon,maxp_lat,center_coord[1],center_coord[0]
   # print ("max precip rate....%f" %mm) 
   # print ("distance from center...%f" %dis)
   
    return (total_precip, total_area,total_tmq)
 
"""
Main Code
"""

"""
directories of input output
"""
teca_dir="/scratch2/scratchdirs/prabhat/TCHero/data/"
out_dir="/global/project/projectdirs/mantissa/climate/Yunjie/TECA/"


"""
loop through year, month 
"""
for year in range(1979,2006):
    check_operator=True  # check whether file exists or not
    teca_file=os.path.join(teca_dir,str(year),"visit_output.txt")
    teca_data=teca_process(teca_file,gI, gJ, gK)
 
    """
    add another column to the teca_data matrix for radius of vanishing wind and total precip
    """
    teca_data["totalprecip"]=0
    teca_data["totalarea"]=0
    teca_data["totaltmq"]=0
 
    """
    loop through yearly teca TC info, calculate radius of each TC
    """
    for it, one in teca_data.iterrows():
        cam_file=one["camfile"]
        cam_file=os.path.join(teca_dir,cam_file)
        print "cam data file....."+cam_file
        TC_center=(one['lat_in'],one['lon_in'],one['time_in']) 
        TC_center_coord=(one['lat'],one['lon'])
        min_press=one['minpsl']
        #print ("max precip from TECA....%f" %one["maxprecip"])
        (lat_axis,lon_axis,press_data, precip_data, tmq_data)=cdf_process(cam_file,TC_center)
        (bound_lat,bound_lon,mask_lat,mask_lon,mask_index)=radius_cal(TC_center,TC_center_coord,lat_axis,lon_axis,min_press,press_data)
        
        #if there is no outmost contour find, skip this loop and go to the next
        
        if bound_lat==():
           continue

        (total_precip,total_area,total_tmq)=precip_cal(mask_index,TC_center_coord,lat_axis,lon_axis,precip_data,tmq_data)
        
        """
        assign total precip data to  teca_data
        in pandas.DataFrame chained index a["column"]["row"]  will not work, use .ix for indexing
        """
 
        teca_data.ix[it,'totalprecip']=total_precip
        teca_data.ix[it,'totalarea']=total_area
        teca_data.ix[it,'totaltmq']=total_tmq
 
        """
        save the bounding box of the tropical cyclone, this can be used for validation wether the radius calculation
        """ 
        out_file=("TC_bounding_box-%d.txt" %year)
 
        box_file=os.path.join(out_dir,out_file)

        if check_operator:   # if this is the first time dealing with file
          if  os.path.exists(box_file):  # if exist then delete
              os.remove(box_file)           

        fid=open(box_file,"a")
        check_operator=False
        fid.write(str(one["id"])+","+str(one["year"])+","+str(one["month"])+","+str(one["day"])+","+str(one["hour"]))
        fid.write("\n")
 
        fid.write(str(one['lat'])+","+str(one['lon']))   #[:5] get less digits
        fid.write('\n')
        for i in bound_lat:
              fid.write(str(i)[:5]+",")
        fid.write('\n')
        for i in bound_lon:
              fid.write(str(i)[:5]+",")
        fid.write('\n')
        for i in mask_lat:
              fid.write(str(i)[:5]+",")
        fid.write('\n')
        for i in mask_lon:
              fid.write(str(i)[:5]+",")
        fid.write('\n')
        fid.close()
        #print teca_data

    print('..................................')

    """
    save all info into file
    """ 
    out_file=("visit_output_process_%04d.txt" %year)
    new_file=os.path.join(out_dir,out_file)
    if os.path.exists(new_file):  #delete the file is already exist
       os.remove(new_file)
    ffid=open(new_file,"w")
    ffid.write("ID, year, month, day, hour, lat, lon, maxwind, mwr, maxprecip, mpr, cat, vort,  minpsl, time_index, lat_index, \
               lon_index, file, total_precip, total_area, total_tmq") 
    ffid.write("\n")
    numpy.savetxt(ffid,teca_data, fmt="%i,%i,%i,%i,%i,%f,%f,%f,%f,%f,%f,%i,%f,%f,%i,%i,%i,%s,%f,%f,%f", delimiter=",")
    ffid.close() 
