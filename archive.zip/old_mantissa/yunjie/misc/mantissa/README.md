mantissa
========

Nervana NERSC collaboration
