"""
visualize feature learned by neon, misclassification example, confusion matrix etc.
Not finished yet, some wired problem on import matplotlib.pyplot.
"""

import os
import numpy
import pickle
import neon.experiments
from neon.experiments import FitPredictErrorExperiment as experiment
import neon.models.mlp
from neon.models.mlp import MLP

import matplotlib
from matplotlib import pyplot
from matplotlib.pyplot import *
#execfile("../../neon_env")

"""
read in the pickle file
Neon save model output or trained parameters into pickle file
"""
fpath="/global/project/projectdirs/nervana/yunjie/climate_neon0.7run/convnet/savedparameter"
fname="clean_nonequal_dropout_epoch10.pkl"

fid=open(os.path.join(fpath,fname),"r")
fdata=pickle.load(fid)

print("loaded neon training results...")


"""
the results are related to the models used to train, reference to Nervana documents on what attrbutes/method available
"""
#print some diagnostic variables about the model

#print("backend ....", fdata.backend)
#print("batch sizes...", fdata.batch_size)
#print("layers....", fdata.layers)
#print("epochs....",fdata.num_epochs)
"""
feature of the first convolutionaly layer 
structure of the CNN is: datalayer, conv layer, pooling layer, (normalization layer), ..... ,fully connected layer, output layer
"""
#-----------------------------
#data layer
datalayer=fdata.layers[0]  # first layer is the data layer
train_image=datalayer.output
train_image_size=datalayer.ofmshape
train_image_convert=train_image.asnumpyarray()
batch_size=datalayer.batch_size
train_image_orig=train_image_convert.reshape(train_image_size[0],train_image_size[1],batch_size)

#plot input images 



#------------------------------
#first conv layer
firstconv=fdata.layers[1]  # second layer in MLP model
in_feat_no=firstconv.nifm     # input NO. feature
out_feat_no=firstconv.nofm    #output NO. feature 
in_feat_shape=firstconv.ifmshape   #output from first data layer
out_feat_shape=firstconv.ofmshape   #output feature shape
receptive_field=firstconv.fshape     # receptive field size
feature=firstconv.output      #feature map

#convert CPUTensor to numpy array
feature_convert=feature.asnumpyarray()

#pick only one input images and see the features learned
feature_convert_reshape=feature_convert.reshape(out_feat_shape[0],out_feat_shape[1],out_feat_no)

#plot learned feature into images 
# the first convolutional layer has 16 feature 
image.imsave("feature.png",feature_see_reshape[:,:,0])

#-----------------------
#followed by pooling layer

firstpool=fdata.layers[2]
in_feat_p=firstpool.nifm
out_feat_p=firstpool.nofm
in_feat_shape_p=firstpool.ifmshape
out_feat_shape_p=firstpool.ofmshape
receptive_field_p=firstpool.fshape
feature_p=firstpool.output

#convert feature to numpy array
feature_convert_p=feature_p.asnumpyarray()

feature_convert_p_reshape=feature_convert_p.reshape()

#------------------------
#second conv layer
secondconv=fdata.layers[3]  # thrid layer in MLP model
in_feat_no2=secondconv.nifm     # input NO. feature
out_feat_no2=secondconv.nofm    #output NO. feature 
in_feat_shape2=secondconv.ifmshape   #output from first data layer
out_feat_shape2=secondconv.ofmshape   #output feature shape
receptive_field2=secondconv.fshape     # receptive field size
feature2=secondconv.output      #feature map

#convert CPU tensor to numpy array
feature_convert2=feature2.asnumpyarray()

#pick only one input images and see the features learned
feature_convert_reshape2=feature_convert2.reshape(out_feat_shape2[0],out_feat_shape2[1],out_feat_no2)

#plot learned feature into image


#--------------------------
#output layer and confusion metrix









