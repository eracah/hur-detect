"""
Provides neon.datasets.Dataset class for ar patches data
here it defines the data set for ARs of west america (note the image size is different between America and Europe AR patches)
"""
import logging
import numpy as np
import h5py
import os
import ipdb

from neon.datasets.dataset import Dataset

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class AR(Dataset):
    """
    Sets up the NERSC Mantissa AR dataset.

    Attributes:
        backend (neon.backends.Backend): backend used for this data
        inputs (dict): structure housing the loaded train/test/validation
                       input data
        targets (dict): structure housing the loaded train/test/validation
                        target data

    Kwargs:
        repo_path (str, optional): where to locally host this dataset on disk
    """

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        if 'repo_path' not in kwargs:
            raise ValueError('Missing repo_path.')

        self.rootdir = os.path.join(self.repo_path)#, self.__class__.__name__)
        print ("data directory  %s" %self.rootdir)
    def load(self, sl=None):
        """
        Read data from h5 file, assume it's already been created.

        Create training and test datasets from 1 or more prognostic variables.
        """
        fname =	os.path.join(self.rootdir, self.hdf5_file)
        print ('working data file %s ' %fname)
        f = h5py.File(fname, 'r')
        #f = h5py.File(os.path.join(self.rootdir, self.hdf5_file), 'r')

        one = f['AR'] # group 1 is AR
        zero = f['Non_AR'] # group 0 is Non_AR

        #ipdb.set_trace()
        # [DEBUG] some debug settings
        v = self.variables          # which variable to pick  
        print ('variables %s'  %v)
        a_tr = self.ar_training_size    # how many training rows * 2
        n_tr = self.non_training_size
        print ('ar trainigng size  %d' %a_tr)
        print ('non ar training size %d' %n_tr)
        a_te = self.ar_testing_size        # how many test rows * 2
        n_te = self.non_testing_size
        print ('ar test size   %d' %a_te)
        print ('non ar testing size %d' %n_te)
        # take equal number of AR and non-AR
        if sl is None:
            sl = slice(None, None, 1)
        #ipdb.set_trace()
        self.inputs['train'] = np.vstack((one[:a_tr,v, sl, sl],
                                          zero[:n_tr,v, sl, sl]))
        
        # one hot encoding required for MLP 
        self.targets['train'] = np.vstack(([[1,0]] * a_tr,
                                           [[0,1]] * n_tr))

        # same with test set
        self.inputs['test'] = np.vstack((one[a_tr:a_tr+a_te,v, sl, sl],
                                         zero[n_tr:n_tr+n_te,v, sl, sl]))

        self.targets['test'] = np.vstack(([[1,0]] * a_te,
                                          [[0,1]] * n_te))

        f.close()
        #ipdb.set_trace()
        # flatten into 2d array with rows as samples
        # and columns as features
        dims = np.prod(self.inputs['train'].shape[1:])
        self.inputs['train'].shape = (a_tr+n_tr, dims)
        self.inputs['test'].shape = (a_te+n_te, dims)

        # shuffle training set
        s = range(len(self.inputs['train']))
        np.random.shuffle(s)
        self.inputs['train'] = self.inputs['train'][s]
        self.targets['train'] = self.targets['train'][s]

        # [DEBUG] shuffle test to create errors
        # s = range(len(self.targets['test']))
        # np.random.shuffle(s)
        # self.targets['test'] = self.targets['test'][s]

        def normalize(x):
            """Make each column mean zero, variance 1"""
            x -= np.mean(x, axis=0)
            x /= np.std(x, axis=0)

        map(normalize, [self.inputs['train'], self.inputs['test']])

        # convert numpy arrays into CPUTensor backend
        self.format()
    
