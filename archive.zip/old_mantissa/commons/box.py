
import numpy as np
import os
import pickle
import h5py
import glob
import matplotlib

import matplotlib.pyplot as plt
import matplotlib.image as mpimg

from scipy import stats

dimX = 158
dimY = 224

var1 = np.random.random([dimX,dimY])
var2 = np.eye(dimX,dimY,1)
var3 = np.zeros([dimX,dimY])

for i in range(0,var1.shape[0]):
    for j in range(0,var1.shape[1]):
        if var1[i,j] >= 20 and var2[i,j] != 0:
            var3[i,j] = var1[i,j]
            print(var1[i,j])

uu = plt.imshow(var3)
mpimg.imsave("/Users/DOE6903584/NERSC/mantissa/commons/box.png", var3)


uu = np.empty([dimX,dimY])
np.zeros([dimX,dimY])

for nonar_file in glob.glob(os.path.join(data_path, "*_nonar_*.pkl")):
    nonar_data = np.array(pickle.load(open(nonar_file,'r'))['TMQ'])

    key = stats.threshold(nonar_data, threshmin=20)
    for i in range(0, key[1].shape[0]):
        for j in range(0, key[1].shape[1]):
            if landmask_data[i,j] != 0 and key[i,j] >= 20:
                uu[i,j] = key[i,j]

    print(nonar_data)


for ar_file in glob.glob("*_ar_*.pkl"):
    pass


def h5file():
    pass

data_h5 = h5py.File(os.path.join(data_path, "mytestfile.hdf5"), 'w')

zero = data_h5.create_dataset("TMQ")
one = data_h5.create_dataset("landmask_filter")

data_h5['zero'] = np.array()
data_h5['one'] = np.array()

# TODO: for AR and non-AR
for file in file_list:

    ar_data = np.array(pickle.load(open(file, 'r')['TMQ']))
#     TODO: calculate the threshold and store it in a numpy array

# TODO: Calculate the intersection

landmask_data = np.array(pickle.load(open(landmask_file, 'r'))['mask'])


# A = matrix('1.0 2.0; 3.0 4.0')
# A
# [[ 1.  2.]
#  [ 3.  4.]]

# j = np.matrix('1 2 3 4 5 6; 1 2 3 4 5 6')

a = np.array([[1,2,3,4,5,6],[1,2,3,4,5,6]])
b = np.array([[1,2,0,4,5,6],[0,0,0,0,0,0]])

# A=np.array([[2,3,4],[5,6,7],[8,9,10]])

# a = np.matrix([1 2 3 4 5 6; 1 2 3 4 5 6')

# b = np.matrix('1 2 3 4 5 6; 0 0 0 0 0 0')

# TODO: Threshold TMQ >= 20 and then intersect
# TMQ > 20

TMQ = ""

x = TMQ.shape.x
y = TMQ.shape.x

landmask = []

# land_feat = []
AR_thr = []
thr = 20

for ix in range(1, x):
    for iy in range(1, y):
        if TMQ(ix, iy) >= thr:
            AR_thr.append(TMQ(ix,iy).val())
            # np.intersect1d()
#         TODO: do threshold

land_feat = np.intersect1d(AR_thr, landmask)


c = np.intersect1d(a,b)

# TODO: Store c as a key on h5

print(c)