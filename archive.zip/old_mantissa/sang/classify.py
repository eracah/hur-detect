# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

import numpy as np
import sklearn.linear_model as lm
import sklearn.preprocessing as pp

# <codecell>

h = np.load('hurricane_all_TMQ.npz')['arr_0']
n = np.load('not_hurricane_all_TMQ.npz')['arr_0']

# <codecell>

meanh = h.mean(axis=0).reshape((33,33))
meann = n.mean(axis=0).reshape((33,33))
vmax = np.max((meanh, meann))
vmin = np.min((meanh, meann))

# <codecell>

fig, axes = subplots(nrows=2, ncols=2, figsize=(5*2, 5*2))
subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=0.1, hspace=0.1)

axes[0,0].imshow(meanh, interpolation='none')
axes[0,0].axis('off')
axes[0,0].set_title('average hurricane')

axes[0,1].imshow(meann, interpolation='none')
axes[0,1].axis('off')
axes[0,1].set_title('average non-hurricane')

axes[1,0].imshow(meanh, vmin=vmin, vmax=vmax, interpolation='none')
axes[1,0].axis('off')
axes[1,0].set_title('average hurricane (color normalized)')

axes[1,1].imshow(meann, vmin=vmin, vmax=vmax, interpolation='none')
axes[1,1].axis('off')
axes[1,1].set_title('average non-hurricane (color normalized)')
show()

# <codecell>

print meanh.min(), meanh.max()
print meann.min(), meann.max()
print vmin, vmax

# <codecell>

print "number of hurricane events:", len(h)
print "number of non-hurricane events:", len(n)

# <codecell>

num = 10000
X = np.concatenate((h[:num], n[:num]), axis=0)
Y = np.array([1]*len(h[:num]) + [0]*len(n[:num]))

# <codecell>

lrX = lm.LogisticRegression(C=10)
lrX.fit(X, Y)

# <codecell>

s = 10000
f = num
t = num + s
testX = np.concatenate((h[f:t], n[f:t]), axis=0)
testY = np.array([1]*s + [0]*s )
predY = lrX.predict(testX)
wrongY = np.where((predY - testY)!=0)[0]

# <codecell>

import sklearn.metrics as mt
cm = mt.confusion_matrix(testY, predY)
cm

# <codecell>

TP = sum((testY==1)*(predY==1))
TN = sum((testY==0)*(predY==0))
FP = sum((testY==0)*(predY==1))
FN = sum((testY==1)*(predY==0))
print TP, FP
print FN, TN

# <codecell>

TPR = float(TP)/(TP+FN)
FPR = float(FP)/(FP+TN)
FNR = float(FN)/(TP+FP)
TNR = float(TN)/(TN+FN)

# <codecell>

print "%.3f %.3f" % (TPR, FPR)
print "%.3f %.3f" % (FNR, TNR)

# <codecell>

## should not be hurricane
fH = np.where((testY==0)*(predY==1))[0]

## should be hurricane
fN = np.where((testY==1)*(predY==0))[0]

print "fH:", sum(fH!=0), '|', fH[:4]
print "fN:", sum(fN!=0), '|', fN[:4]

# <codecell>

l = 10

fig, axes = subplots(nrows=l, ncols=2, figsize=(3*2, 3*l))
subplots_adjust(left=0, bottom=0, right=1, top=1, wspace=0.1, hspace=0.1)

for one, hi, ni in zip(axes, fH[:l], fN[:l]):
    one[0].imshow(testX[hi].reshape((33,33)), vmin=vmin, vmax=vmax, interpolation='none')
    one[0].axis('off')
    one[0].set_title('should not be hurricane: ' + str(hi))

    one[1].imshow(testX[ni].reshape((33,33)), vmin=vmin, vmax=vmax, interpolation='none')
    one[1].axis('off')
    one[1].set_title('should be hurricane: ' + str(ni))


