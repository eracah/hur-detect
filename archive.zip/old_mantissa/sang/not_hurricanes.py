# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

import os
import os.path as op
import numpy as np
import pandas as pd
import sklearn.preprocessing as pp
import netCDF4 as cdf

import matplotlib
matplotlib.use('agg')
from matplotlib.pyplot import *

# <codecell>

TCdir = op.join(os.environ['HOME'], 'Data', 'climate', 'TC_analysis')
keys = [u'PSL', u'T200', u'T500', u'TMQ', u'TS',
        u'U850', u'UBOT', u'V850', u'VBOT']

# number of grid points
# I: hours
# J: latitude
# K: longitude
IJK = (8, 768, 1152)
I, J, K = IJK

# step size between grid points (in degrees)
dJ = 180./(J-1)
dK = 360./K

# grid locations
gI = np.arange(0, 23, 3)
gJ = np.arange(-90, 90 + dJ, dJ)
gK = np.arange(0, 360, dK)

# <codecell>

def nearestindex(x, v):

    from numpy.linalg import norm
    from numpy import searchsorted

    r = searchsorted(v, x, 'right') - 1
    return r if norm(v[r]-x) <= norm(v[r+1]-x) else r+1

def hurricanetracks(f, hr, lat, lon):

    from numpy import arange, genfromtxt
    from pandas import DataFrame
    
    ctr = genfromtxt(f, delimiter=',', names=True, usecols=(0,1,2,3,4,5,6), 
                     dtype=('i','i','i','i','i','f','f'))
    ctr = DataFrame(ctr)
    ctr['ihour'] = nearestindex(x=ctr['hour'], v=hr) ## matrix index 
    ctr['ilon'] = nearestindex(x=ctr['lon'], v=lon)  ## nearest matrix index
    ctr['ilat'] = nearestindex(x=ctr['lat'], v=lat)  ## nearest matrix index
    ctr['file'] = ['cam5_1_amip_run2.cam2.h2.%4d-%02d-%02d-00000.nc' % 
                   (one['year'], one['month'], one['day']) 
                   for i, one in ctr.iterrows()]
    
    return ctr

def save_events(f, ev):
    from pickle import dump
    with open(f, 'wb') as fp:
        dump(ev, fp)

# <codecell>

def comp_box(dims, info, patch_size=32):

    imax, jmax, kmax = dims
    s = patch_size/2
    
    jintv = [(a, b) for a, b in zip(info['ilat']-s, info['ilat']+s+1)]
    kintv = [(a, b) for a, b in zip(info['ilon']-s, info['ilon']+s+1)]

    jok = [all((0 <= a, b < jmax)) for a, b in jintv]
    kok = [all((0 <= a, b < kmax)) for a, b in kintv]
    allok = [a and b for a, b in zip(jok, kok)]
    
    return [one for one in zip(info['ihour'], jintv, kintv, allok)]

def cut_box(d, info, dims=None):

    from numpy import take, arange, remainder
    
    imax, jmax, kmax = d.shape if dims is None else dims
    
    imgs = []
    for i_, j_, k_, ok_ in info:

        if ok_:
            x = d[i_, slice(*j_), slice(*k_)]
        else:
            x = take(d[i_], remainder(arange(*j_), jmax), axis=0, mode='wrap')
            x = take(x, remainder(arange(*k_), kmax), axis=1, mode='wrap')

        imgs += [x]

    return imgs

def image_squares(info, keys, prefix, patch_size=32):
    
    from os.path import join
    from pandas import concat
    
    evimg = dict([(k,[]) for k in keys])
    evlst = None
    for f, ev in info.groupby('file'):

        d = cdf.Dataset(join(prefix, f), 'r')
        evlst = concat((evlst, ev))
        dshape = d.variables['TMQ'].shape
        imbox = comp_box(dshape, ev, patch_size)
        for k in keys:
            imgs = cut_box(d.variables[k], imbox)
            evimg[k] += imgs

    return evlst, evimg

# <codecell>

def rand_center(n, I=8, J=768, K=1152):
    
    """
    randomly select image patch centers
    """

    from numpy.random import randint, triangular
    from numpy import int_
    
    i = randint(low=0, high=I, size=n)
    j = int_(triangular(left=0, mode=J/2, right=J, size=n))
    k = randint(low=0, high=K, size=n)
    
    return i, j, k

def strTimeProp(start, end, format, prop):

    """
    Get a time at a proportion of a range of two formatted times.

    start and end should be strings specifying times formated in the
    given format (strftime-style), giving an interval [start, end].
    prop specifies how a proportion of the interval to be taken after
    start.  The returned time will be in the specified format.
    (from stackoverflow)
    """
    
    from time import mktime, strptime, strftime, localtime

    stime = mktime(strptime(start, format))
    etime = mktime(strptime(end, format))

    ptime = stime + prop * (etime - stime)

    return strftime(format, localtime(ptime))


#def randomDate(start="1979-01-01", end="2006-12-13"):
def randomDate(start="1979-08-06", end="1979-09-05"):

    from random import random    
    return strTimeProp(start, end, '%Y-%m-%d', random())

# number of events to grab
n = 200

# generate random time and centers
c = rand_center(n)
# generate random dates (between default arguments of 'randomDate' function)
tstr = [randomDate() for i in range(n)]
t = np.array([map(int, a.split('-')) for a in tstr])

# construct data frame for 'image_squares' function
ctr = pd.DataFrame()
ctr['year'] = t[:, 0]
ctr['month'] = t[:, 1]
ctr['day'] = t[:, 2]
ctr['hour'] = gI[c[0]]
ctr['lat'] = gJ[c[1]]
ctr['lon'] = gK[c[2]]
ctr['ihour'], ctr['ilat'], ctr['ilon'] = c
ctr['file'] = ['cam5_1_amip_run2.cam2.h2.%4d-%02d-%02d-00000.nc' % 
               (one['year'], one['month'], one['day']) 
               for i, one in ctr.iterrows()]

# <codecell>

# for debugging. disable for full run
f5 = ['cam5_1_amip_run2.cam2.h2.1979-08-07-00000.nc',
      'cam5_1_amip_run2.cam2.h2.1979-09-04-00000.nc']
ctr = ctr[[one in f5 for one in ctr['file']]]

# <codecell>

# save by year and month
for i_yrmo, yrmo in ctr.groupby(['year', 'month']):

    ev, img = image_squares(yrmo, keys, TCdir)

    if len(img[keys[0]]) != len(yrmo):
        print "tracked points (%d) and image patch (%d) counts differ" % (len(img[keys[0]]), len(yrmo))

    # f = "hurricanes-%4d" % i_yrmo
    f = "not_hurricanes-%4d-%02d" % i_yrmo
    save_events(f+'_imgs.pkl', img)
    yrmo.to_pickle(f+'_list.pkl')    

