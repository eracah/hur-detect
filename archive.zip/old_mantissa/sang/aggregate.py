# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

import glob, pickle, os
dn = '/home/syoh/Data/climate/results'

fn = glob.glob(os.path.join(dn,'not_hurricanes-*_imgs.pkl'))
fn.sort()
print "number of files:", len(fn)

ln = glob.glob(os.path.join(dn,'not_hurricanes-*_list.pkl'))
ln.sort()

keys = [u'TMQ', u'PSL', u'T200', u'T500', u'TS', u'U850', u'UBOT', u'V850', u'VBOT']

# <codecell>

# read specs
l = []
for i, one in enumerate(ln):
    f = pickle.load(open(one))
    l += [f]
llen = np.array([0] + [len(one) for one in l])

# consolidate images
lcs = llen.cumsum()
slist = lcs[:-1]
elist = lcs[1:]
for k in keys:
    print k,
    # secure memory
    d = np.zeros((sum(llen), 33**2))

    i = 0
    for s_, e_, f_ in zip(slist, elist, fn):
        print i, 
        f = pickle.load(open(f_))
        d[s_:e_] = np.array(f[k]).reshape((-1, 33**2))
        i += 1
    
    oname = 'not_hurricane_all_' + k
    np.savez_compressed(oname, d)

