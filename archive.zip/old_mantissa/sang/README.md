Extracts hurricane events from simulation data and TECA output.
Also, generates non-events by randomly selecting image patches in simulation data.

Relevant files are:

* hurricanes.ipynb
* not_hurricanes.ipynb
* plot_events.ipynb

All *.py files are overwritten when their corresponding *.ipynb files are saved ipython notebook setting.
