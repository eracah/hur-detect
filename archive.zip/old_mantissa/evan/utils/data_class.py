import sys
#where neon and other libraries are
sys.path.append("/project/projectdirs/nervana/jusk/experimental/site-packages/")

# neon dependencies
import logging
import neon
import neon.backends
from neon.backends import gen_backend
# from neon.backends.backend import Backend
from neon.layers import FCLayer, DataLayer, CostLayer
from neon.models import MLP
from neon.transforms import RectLin, Logistic, CrossEntropy
from neon.datasets import MNIST
from neon.experiments import FitPredictErrorExperiment
from neon.datasets.dataset import Dataset

logging.basicConfig(level=20)
logger = logging.getLogger()

class AR(Dataset):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        
        self.data_train = self.data['data_train']
        self.data_test = self.data['data_test']
        self.labels_train = self.data['labels_train']
        self.labels_test = self.data['labels_test']
                
#     def initialize(self):
#         pass
    
    def load(self, backend=None, experiment=None):
        # Dataset.inputs
        
#         self.backend = None
        self.inputs = {'train': self.data_train,
                       'test': self.data_test,
                       'validation': None}

        self.targets = {'train': self.labels_train,
                        'test': self.labels_test,
                        'validation': None}
        
        self.format()
        
def create_model(nin):
    layers = []
    # layers.append(DataLayer(nout=nin[0], name='input'))
    # layers.append(DataLayer(nout=784, name='input'))
    # layers.append(DataLayer(nout=35392, name='input'))
    layers.append(DataLayer(name='d0', ofmshape=[35392, 1], is_local=True, nofm=1))
            # name='d0', ofmshape=[xx_size, yy_size]
        # is_local: True,
        # nofm: 3,
        # ofmshape: [32, 32],
#       },
    layers.append(FCLayer(nout=100, activation=RectLin(), name='h0'))
    layers.append(FCLayer(nout=10, activation=Logistic(), name='h1'))
    layers.append(CostLayer(cost=CrossEntropy(), name='y'))
    # model = MLP(num_epochs=10, batch_size=128, layers=layers)
    model = MLP(num_epochs=10, batch_size=224, layers=layers)
    return model

