"""
Provides neon.datasets.Dataset class for hurricane patches data
"""
import logging
import numpy as np
import h5py
import os
from neon.datasets.dataset import Dataset
import pickle 
from datetime import datetime as date
import copy
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class Hurricane(Dataset):
    """
    Sets up the NERSC Mantissa hurricane dataset.
    Attributes:
        backend (neon.backends.Backend): backend used for this data
        inputs (dict): structure housing the loaded train/test/validation
                       input data
        targets (dict): structure housing the loaded train/test/validation
                        target data
    Kwargs:
        repo_path (str, optional): where to locally host this dataset on disk
    """

    def __init__(self, **kwargs ):
        self.__dict__.update(kwargs)
        if 'repo_path' not in kwargs:
            raise ValueError('Missing repo_path.')
        if 'data_path' not in kwargs:
            raise ValueError('Missing data_path.')
        if 'hdf5_file' not in kwargs:
            raise ValueError('Missing hdf5 file.')

        now = date.now()

        #if sttring has env variables or ~ then these are expanded
        self.repo_path = os.path.expandvars(os.path.expanduser(self.repo_path))


        self.repo_path = os.path.join(self.repo_path, 'HR' )

        if not (os.path.isdir(self.repo_path)):
            os.mkdir(self.repo_path)

        self.repo_path = os.path.join(self.repo_path, '%s_%s_%s_%s_%s'%(now.month, now.day, now.year, now.hour, now.minute))

        if not (os.path.isdir(self.repo_path)):
            os.mkdir(self.repo_path)
        

        # self.rootdir = os.path.join(self.repo_path)# self.__class__.__name__)

    def get_raw_train_test(self, seed):
        
        fpath=os.path.join(self.data_path, self.hdf5_file)
        f = h5py.File(fpath, 'r')
        
        one = f['1']
        zero = f['0']

        # [DEBUG] some debug settings
        # which variables to pick
        v = self.variables if 'variables' in self.__dict__ else range(8)
        tr = self.training_size
        te = self.test_size
        # take equal number of hurricanes and non-hurricanes
        self.inputs['train'] = np.vstack((one[:tr, v], zero[:tr, v]))

        # one hot encoding required for MLP
        self.targets['train'] = np.vstack(([[1, 0]] * tr, [[0, 1]] * tr))

        # same with validation set
        self.inputs['test'] = np.vstack((one[tr:tr+te, v],
                                              zero[tr:tr+te, v]))
        self.targets['test'] = np.vstack(([[1, 0]] * te, [[0, 1]] * te))

        f.close()
       

        # shuffle training set
        s = range(len(self.inputs['train']))
        t = range(len(self.inputs['test']))
        np.random.RandomState(seed).shuffle(s)
        np.random.RandomState(seed).shuffle(t)
        self.inputs['train'] = self.inputs['train'][s]
        self.targets['train'] = self.targets['train'][s]


        self.inputs['test'] = self.inputs['test'][t]
        self.targets['test'] = self.targets['test'][t]

        return self.inputs['train'], self.inputs['test']


    def preprocess(self):
        # flatten into 2d array with rows as samples
        # and columns as features
        dims = np.prod(self.inputs['train'].shape[1:])
        self.inputs['train'].shape = (2*self.training_size, dims)
        self.inputs['test'].shape = (2*self.test_size, dims)


        def normalize(x):
            """Make each column mean zero, variance 1"""
            x -= np.mean(x, axis=0)
            x /= np.std(x, axis=0)

        map(normalize, [self.inputs['train'], self.inputs['test']])

        # convert numpy arrays into CPUTensor backend
        self.format()



    def load(self, backend=None, experiment=None):
        """
        Read data from h5 file, assume it's already been created.
        Create training and validation datasets from 1 or more
        prognostic variables.
        """

        
        seed = int(np.random.randint(1,25,1))
        


        #if the same test and train size is used this
        #function is deterministic in the seeds even though it shuffles data
        self.get_raw_train_test(seed)

        #all the info needed to recreate the training and test like they are for this run
        re_creation_dict = {'tr_size': self.training_size,
                     'te_size': self.test_size,
                     'type': 'hr',
                     'seed': seed,
                     'h5_file': self.hdf5_file,
                     'data_path': self.data_path }

        re_creation_dict_path = os.path.join(self.repo_path, 're_creation.pkl')


        #save the re_creation dict in same place as the inference results
        pickle.dump(re_creation_dict, open(re_creation_dict_path, 'w'))

        self.preprocess()
       
     

       

        



